/*
 * @Author: AMIRIOX無暝 
 * @Date: 2020-06-09 23:11:17 
 * @Last Modified by: AMIRIOX無暝
 * @Last Modified time: 2020-06-09 23:11:39
 */
//! because of history 
// #ifndef _STDINT_HPP_
// #define _STDINT_HPP_
// #include "basetype.hpp"
// #include <bits/stdc++.h>

// #include "STDiNt.hpp"
// #include "STDeRrOr.hpp"
// #include "STDbOoL.hpp"
// #include "STDcHaR.hpp"
// #include "STDsTrInG.hpp"
// #include "STDdOuBlE.hpp"


// class iNt;
// class dOuBlE;
// class bOoL;
// class sTrInG;
// class cHaR;

// class iNt {
//    private:
//     int value;
//     // bool isError;

//    public:
//     iNt(int val = 0 /*,bool isErr=false*/) : value(val) /*,isError(isErr)*/ {}
//     int getValue() { return value; }
//     iNt operator+(dOuBlE& other) {
//         int tmp = int(other.getValue());
//         return this->getValue() + tmp;
//     }
//     iNt operator+(iNt& other) { return this->getValue() + other.getValue(); }
//     iNt operator<(iNt& other) { return this->getValue() < other.getValue(); }
//     iNt operator>(iNt& other) { return this->getValue() > other.getValue(); }
//     void operator+(cHaR& other) {
//         // isError=true;
//         throw BadCast("iNt + cHar is not allowed.");
//     }
//     void print() { std::cout << value; }
//     void println() { std::cout << value << std::endl; }
//     // TODO operator, . / * & ^ % ....etc
// };
// #endif