# Hello, world!
```
#Language Jvav Made By Dr.ZhangHaoYang
int mAiN()
 output "Hello, world!"
```