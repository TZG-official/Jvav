# Type convert
```
#Language Jvav Made By Dr.ZhangHaoYang
int mAiN()
 int iNt = inputWord
 char cHaR = iNt
 output cHaR
 string sTrInG = inputLine
 double dOuBlE = sTrInG
 cout dOuBlE
 ```