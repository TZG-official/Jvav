# 标识符
`标识符`是[函数](function.md)，[变量](variable.md)所使用的名字。  
`标识符`采用了一种新型命名风格，`uPpEr_lOwEr_cAsE` 命名风格。  
具体规则如下：  
* 由大写字母，小写字母，数字与_组成。
* 每相隔一个字母必须改变大小写，且一个单词的开头必须为小写。
* 数字，"_"的后面若跟字母，必须跟小写字母。  

例如：  
```
mY_sTrInG
aRgUmEnT1tYpE
iNdEx_oF_vArIaBlE
```