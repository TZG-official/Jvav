# 文件格式
Jvav 一共支持三种文件格式，分别为 Jvav 源文件, Jvav 可执行文件, 二进制模块。
## Jvav 源文件（Jvav Source）
`Jvav 源文件` 是存放 Jvav 程序源代码的文件。他的文件后缀名为 `.jvav` 。  
为统一标准~~技术不足~~，请将 `Jvav 源文件` 的文本编码改为 ***ASCII编码***（否则会出现中文无法正常显示的问题）。  
所有 `Jvav 源文件` 都必须在开头写下这样一条作者声明：  
```
#Language Jvav Made By Dr.ZhangHaoYang
```
Jvav 抛弃了复杂的类，改为以函数的方式运行。程序开始后，会自动运行`mAiN`函数。更多详情请查看[函数](function.md)。  
`Jvav 源文件`可以通过[jvav 工具](../Tools/Jvav.md)来运行。
## Jvav 可执行文件（Jvav Runnable）
`Jvav 源文件` 是由多个`二进制模块`打包成的文件。他的文件后缀名为 `.jvr` 。  
目前尚未完成。  
## 二进制模块（Binary Module）
`二进制模块` 是由`Jvav 源文件`编译而成的文件。他的文件后缀名为 `.bnm` 。  
~~俗称编你妈文件~~  
目前尚未完成。  