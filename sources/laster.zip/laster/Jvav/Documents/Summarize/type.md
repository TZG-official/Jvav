# 数据类型
Jvav 中有八种不同的`数据类型`。
## int
即整数型。  
可以通过赋值直接转换为 `string`，`bool`。也可以尝试转换为`long`，`float`，`double`，`char`。  
## long
即长整数型。  
可以通过赋值直接转换为 `string`，`bool`。也可以尝试转换为`int`，`float`，`double`，`char`。  
## float
即浮点型。  
可以通过赋值直接转换为 `string`，`bool`。也可以尝试转换为`int`，`long`，`double`，`char`。  
## double
即双浮点型。  
可以通过赋值直接转换为 `string`，`bool`。也可以尝试转换为`int`，`long`，`float`，`char`。  
## bool
即布尔型。
仅有两种数值，`true` 与 `false`。  
将`bool`转换为其他类型时，`true`会转换为1，`false`会转换为0。  
将其他数据类型转换为`bool`时，除了0转换为`true`外，其余均转换为`false`。
## char
即字符型。  
存储一个单独的字符，以单引号 `'` 引起。如`'A'`。  
可以与`int`互相转换，根据`ASCII码`转换。
## string
即字符串型。
存储一串字符，以双引号 `"` 引起。如`"Hi"`。  
可以尝试转换为其他类型。
## void
即空类型。  
只可以用于[函数](function.md)的返回值，无内容。