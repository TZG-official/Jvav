/*
    Jvav in Lvinx
    Author: yuzijiangorz
    Time: 2020/5/23 4:51pm
    TODO: Jvav in Lvinx(Linux)
*/

#include <bits/stdc++.h>
#include <unistd.h>
#define cls system("clear")
using namespace std;
#ifdef WIN32
#error 这个应用只能在Lvinx(Linux)下进行!请切换到Lvinx下运行！
#endif
/*
格式: echo "\033[字背景颜色;字体颜色m字符串\033[0m"
例如:
echo "\033[41;36m something here \033[0m" 
其中41的位置代表底色, 36的位置是代表字的颜色
那些ascii code 是对颜色调用的始末. 
\033[ ; m …… \033[0m 
字背景颜色范围:40----49
40:黑
41:深红
42:绿
43:黄色
44:蓝色
45:紫色
46:深绿
47:白色
字颜色:30-----------39
30:黑
31:红
32:绿
33:黄
34:蓝色
35:紫色
36:深绿
37:白色
===============================================ANSI控制码的说明 
\33[0m 关闭所有属性 
\33[1m 设置高亮度 
\33[4m 下划线 
\33[5m 闪烁 
\33[7m 反显 
\33[8m 消隐 
\33[30m -- \33[37m 设置前景色 
\33[40m -- \33[47m 设置背景色 
\33[nA 光标上移n行 
\33[nB 光标下移n行 
\33[nC 光标右移n行 
\33[nD 光标左移n行 
\33[y;xH设置光标位置 
\33[2J 清屏 
\33[K 清除从光标到行尾的内容 
\33[s 保存光标位置 
\33[u 恢复光标位置 
\33[?25l 隐藏光标 
\33[?25h 显示光标
***************************
*/
/*1000000μs=1s*/
#define ONESEC 1000000
string c,inp,oup;
int lang;
double nowver=1.12;
void delf(char*);
int engco();
int engmode();
int chico();
int chimode();
int main(void)
{
    
    printf("setting patch...\n");
    printf("initialization...\n");
    engmode();
}
void delf(char* fname)
{
    char* command;
    sprintf(command,"rm %s",fname);
    system(command);
}
int co()
{
en_main:
{
    char w;
    printf("\r\r~/root/Jvav>");
    getline(cin,c);
    if(c=="leave")
    {
                cls;
                printf("Are you sure leave Jvav? (y/n)");
                scanf("%c",&w);
                if(w=='y') {cls;exit(0);}
                else if(w=='n') cls;goto en_main;
    }
    else if(c=="help")
    {
        cls;
        printf("----Jvav help------Page(1/1)---\n\
                help:Get help\n  leave:Exit Jvav console\n  output:Output characters(use var can output input characters)\n  input:Input characters\n  upgrade:Detect upgrades and updates online\n  language:setting the program language\n  info:know about Jvav(you can also know about it in jvav.top)\n  clear: clear the Jvav progammer\n\
                ----Jvav help------Page(1/1)---\n");
        getchar();
        goto en_main;
    }
    else if (c=="input")
    {
        printf("~/root/Jvav/input.Jvav>");
        getline(cin,inp);
        printf("input characters save...\n");
        usleep(1000000);
        goto en_main;
    }
    else if(c=="output")
    {
        printf("~/root/Jvav/output.Jvav>");
        getline(cin,oup);
        if(oup=="var") {cout<<inp<<'\n';goto en_main;}
        else {cout<<oup<<'\n';goto en_main;}
    }
    else if(c=="upgrade")
    {
        system("wget https://cdn.yuzijiangorz.xyz/newver.txt");
        ifstream outf;
        double newver;
        outf.open("newver.txt");
        outf>>newver;
        if(nowver>newver) {printf("\033[41;36m Error: the jvav program you using maybe is a program from future.Please check you are setting version or not.\033[0m");outf.close();system("rm newver.txt");cls;goto en_main;}
        else if(nowver==newver) {printf("you are using the newest version.");outf.close();system("rm newver.txt");cls;usleep(1000000);goto en_main;}
        else {system(" echo \"\"you are not in the newest version. upgrade..\"\"");system("wget https://jvav.top/sources/laster.zip");printf("download sucess! please run the newest Jvav Progammer!\n");outf.close();("rm newver.txt");exit(0);}
   
    }
    else if(c=="info")
    {
        cout << "Jvav Programm Ver.1.2 Pre1\nIt's just a joke, but we still make it, and the joke was first brought by Zhang Haoyang.\nThis version supports running away from jdk.\nThe person writing the program is 30266.\nLinux mode by yuzijiangorz\n";
        getchar();
        goto en_main;
    }
    else if(c=="language")
    {
        cout << "Please enter the setting language(en/zh):";
        string language;
        cin >> language;
        if (language == "en") {
            cls;
            goto en_main;
        }
        else if (language == "zh") {
            cls;
            goto zh_mode;
        }
        else {
            cout << "We don't support this language\n";
            usleep(ONESEC);
            cls;
            goto en_main;
        }
    }
    else if(c=="clear")
    {
        cls;
        goto en_main;
    }
 else printf("Uknown command! type 'help' for help!\n");goto en_main;

}

zh_mode:
{
    cout<<"  初始化...\n";
    usleep(ONESEC);
    cout<<"等待界面出发点...\n";
    usleep(ONESEC);
    cout << "--------------------------------------------\n";
    cout << "| Jvav编译器             版本：1.2 预览版3 |\n";
    cout << "| 作者：张浩洋大师           编写者：30266  |\n";
    cout << "| 通过输入'帮助'来获得帮助        johnvp22  |\n";
    cout << "| Lvinx(Linux)模式由yuzijiangorz编写      |\n";
    cout << "| 现已支持在线推送更新！                    |\n";
    cout << "--------------------------------------------\n";
    goto zh_main;
}
zh_main:
{
    string chinp,choup,chc,chw;
    printf("\r\r~/管理员/Jvav>");
    getline(cin,chc);
    if(chc=="离开")
    {
        printf("确定要离开Jvav吗(是/否)");
            cin>>chw;
            if(chw=="是") {cls;exit(0);}
            else if(chw=="否") {goto zh_main;}
    }
    else if(chc=="帮助")
    {
        cls;
         cout << "----Jvav帮助---第(1/1)页----\n";
        cout << "  帮助 [页码]:获取帮助\n  退出:退出Jvav\n  输出:输出字符\n  输入:输入字符以便调用(输入'变量'来存储输入的字符)\n  更新:在线检测版本更新\n  语言:设置Jvav的语言\n  关于:获取关于Jvav的信息(你也可以在官网Jvav.top上了解)\n  清屏: 清除Jvav编译器的屏幕\n";
        cout << "----Jvav帮助---第(1/1)页----\n";
        getchar();
        goto zh_main;
    }
    else if (chc=="输入")
    {
        printf("~/管理员/Jvav/输入.Jvav>");
        getline(cin,chinp);
        printf("保存输入变量...\n");
        usleep(1000000);
        goto zh_main;
    }
    else if(chc=="输出")
    {
        printf("~/管理员/Jvav/输出.Jvav>");
        getline(cin,choup);
        if(choup=="变量") {cout<<chinp<<'\n';goto zh_main;}
        else {cout<<choup<<'\n';goto zh_main;}
    }
     else if(chc=="更新")
    {
        system("wget https://cdn.yuzijiangorz.xyz/newver.txt");
        ifstream choutf;
        double chnewver;
        choutf.open("newver.txt");
        choutf>>chnewver;
        if(nowver>chnewver) {printf("\033[41;36m 系统错误: 版本序列错误。你可能正在使用一个来自未来的版本。请检查你是否修改了版本好 \033[0m");choutf.close();system("rm newver.txt");cls;goto zh_main;}
        else if(nowver==chnewver) {printf("\r\r你正在使用最新的版本");choutf.close();system("rm newver.txt");cls;usleep(1000000);goto zh_main;}
        else {printf("检测到为旧版本 升级...");usleep(ONESEC);system("wget https://jvav.top/sources/laster.zip");printf("下载成功! 请运行最新版本!\n");choutf.close();system("rm newver.txt");exit(0);}
   
    }
    else if(chc=="清屏") {cls; goto zh_mode;}
    else if(chc=="关于")
    {
         cout << "Jvav编程器，版本为1.2预览版3。\n这只是一个梗，但是我们依然把它变成了现实。最早是张浩洋提出的这个梗。\n该版本支持脱离jdk的运行(实际上更新需要)。\n该程序编写者为30266和johnvp22(做了一些说明和bug修复)。\n  Lvinx(Linux)模式由yuzijiangorz编写 ";
        getchar();
        goto zh_main;
    }
    else if(c=="语言")
    {
        cout << "请输入你想设置的语言(英文/简体中文):";
        string lo;
        cin >> lo;
        if (lo == "英文") {
            cls;
            goto en_main;
        }
        else if (lo == "简体中文") {
            cls;
            goto zh_mode;
        }
        else {
            cout << "我们不支持此语言\n";
            usleep(ONESEC);
            cls;
            goto en_main;
        }
    }
    else {cout << "未知的命令！通过输入'帮助'来获得帮助!\n";goto zh_main;}
}
}
int engmode()//英文模式
{
     printf("\n            --------------------------------------------\n\
            | Jvav Programmer             v1.12        |\n\
            | By Dr.ZhangHaoYang          Sorter 30266 |\n\
            | Lvinx(Linux) mode by yuzijiangorz        |\n\
            | Enter'help'to get help!                  |\n\
            | Chinese Simplified is now supported!     |\n\
            --------------------------------------------\n\
           ");
    co();
}
